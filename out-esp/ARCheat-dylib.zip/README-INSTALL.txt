ARCheat.dylib —— 只显示形态（骨骼 / 装备 / 物资）

安装（二选一）

A. TrollFools（推荐，不动游戏包以外的任何东西）
   1. 设备上打开 TrollFools
   2. 选择 Arena Breakout (com.proximabeta.mf.uamo)
   3. 选择本目录的 ARCheat.dylib -> Inject
   4. 启动游戏；三指双击屏幕切换菜单

B. 系统级注入（roothide Bootstrap）
   把 ARCheat.dylib 与 ARCheat.plist 一起放进
   /var/containers/Bundle/tweaksupport/Library/MobileSubstrate/DynamicLibraries/
   然后 respring

回滚
   A: TrollFools 里移除注入，或删掉 app 重装
   B: 删掉上面两个文件后 respring

止血开关
   建一个空文件：/var/mobile/Library/Preferences/.sbx.state
   之后注入即静默（不装 hook、不画东西）

注意
   - 偏移是占位符，必须先按 Docs/ESP-ONLY.md 的验收顺序填实测值
   - 这个 dylib 不写游戏内存、不发包，只读
